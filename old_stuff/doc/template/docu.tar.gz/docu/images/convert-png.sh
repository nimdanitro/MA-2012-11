for file in $(ls -1 *.eps)
	do
	target=$(echo $file|sed s/\.eps$/\.png/)
	#echo $target
	convert -density 300 -resample 300 $file $target
done
