find -name "*.eps" -exec epstopdf {} \;
